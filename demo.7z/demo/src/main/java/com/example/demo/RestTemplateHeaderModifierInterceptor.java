package com.example.demo;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.ContextPropagators;
import io.opentelemetry.context.propagation.TextMapSetter;
import io.opentelemetry.exporter.logging.LoggingMetricExporter;
import io.opentelemetry.exporter.otlp.trace.OtlpGrpcSpanExporter;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.metrics.export.PeriodicMetricReader;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.BatchSpanProcessor;
import io.opentelemetry.sdk.trace.export.SpanExporter;
import io.opentelemetry.semconv.resource.attributes.ResourceAttributes;

@Component
public class RestTemplateHeaderModifierInterceptor implements ClientHttpRequestInterceptor {


    TextMapSetter<HttpRequest> setter = new TextMapSetter<HttpRequest>() {

        @Override
        public void set(final HttpRequest carrier, final String key, final String value) {
            // Insert the context as Header
            carrier.getHeaders().add(key, value);
        }
    };

    public OpenTelemetry getTelemetry() {

        final SpanExporter spanExporter =
            OtlpGrpcSpanExporter.builder().setEndpoint("http://localhost:4317").setTimeout(30, TimeUnit.SECONDS).build();

        final Resource resource =
            Resource.getDefault().merge(Resource.create(Attributes.of(ResourceAttributes.SERVICE_NAME, "test-service")));

        final SdkTracerProvider sdkTracerProvider = SdkTracerProvider.builder()
            .addSpanProcessor(BatchSpanProcessor.builder(spanExporter).build()).setResource(resource).build();

        final SdkMeterProvider sdkMeterProvider = SdkMeterProvider.builder()
            .registerMetricReader(
                PeriodicMetricReader.builder(LoggingMetricExporter.create()).setInterval(Duration.ofMillis(800l)).build())
            .setResource(resource).build();

        return OpenTelemetrySdk.builder().setTracerProvider(sdkTracerProvider).setMeterProvider(sdkMeterProvider)
            .setPropagators(ContextPropagators.create(W3CTraceContextPropagator.getInstance())).buildAndRegisterGlobal();
    }

    @Override
    public ClientHttpResponse intercept(final HttpRequest request, final byte[] body,
        final ClientHttpRequestExecution execution) throws IOException {

        final String spanName = request.getMethodValue() + " " + request.getURI().toString();

        final OpenTelemetry openTelemetry = this.getTelemetry();
        final Tracer tracer = openTelemetry.getTracer("com.tomtom.orbis.sourceprocessingutility", "1.0.0");
        final Span outGoing = tracer.spanBuilder("Client").setSpanKind(SpanKind.CLIENT).startSpan();
        try (Scope scope = outGoing.makeCurrent()) {
            outGoing.setAttribute("HTTP_METHOD", "GET");
            openTelemetry.getPropagators().getTextMapPropagator().inject(Context.current(), request, setter);
            final ClientHttpResponse response = execution.execute(request, body);
            System.out.println("Request sent from RestTemplateInterceptor");

            return response;
        } finally {
            outGoing.end();
    }

    }
}