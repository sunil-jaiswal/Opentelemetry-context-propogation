package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

public class RestTemplateItegrationTest {

    @Autowired
    RestTemplate restTemplate;

    public static void main(final String[] args) {
        new RestTemplateItegrationTest().givenRestTemplate_whenRequested_thenLogAndModifyResponse();
    }
    public void givenRestTemplate_whenRequested_thenLogAndModifyResponse() {


    }
}