/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.example.demo;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.propagation.ContextPropagators;
import io.opentelemetry.exporter.logging.LoggingMetricExporter;
import io.opentelemetry.exporter.otlp.trace.OtlpGrpcSpanExporter;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.metrics.export.PeriodicMetricReader;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.BatchSpanProcessor;
import io.opentelemetry.sdk.trace.export.SpanExporter;
import io.opentelemetry.semconv.resource.attributes.ResourceAttributes;

//@Configuration
public class TelemetryConfig {

    // @Bean
    public OpenTelemetry getTelemetry() {

        final SpanExporter spanExporter =
            OtlpGrpcSpanExporter.builder().setEndpoint("http://localhost:4317").setTimeout(30, TimeUnit.SECONDS).build();


        final Resource resource =
            Resource.getDefault().merge(Resource.create(Attributes.of(ResourceAttributes.SERVICE_NAME, "test-service")));

        final SdkTracerProvider sdkTracerProvider = SdkTracerProvider.builder()
            .addSpanProcessor(BatchSpanProcessor.builder(spanExporter).build()).setResource(resource).build();

        final SdkMeterProvider sdkMeterProvider = SdkMeterProvider.builder()
            .registerMetricReader(
                PeriodicMetricReader.builder(LoggingMetricExporter.create()).setInterval(Duration.ofMillis(800l)).build())
            .setResource(resource).build();

        return OpenTelemetrySdk.builder().setTracerProvider(sdkTracerProvider).setMeterProvider(sdkMeterProvider)
            .setPropagators(ContextPropagators.create(W3CTraceContextPropagator.getInstance())).buildAndRegisterGlobal();
    }

    // @Bean
    public Tracer getTracer() {
        final OpenTelemetry openTelemetry = getTelemetry();
        return openTelemetry.getTracer("com.tomtom.orbis.sourceprocessingutility", "1.0.0");
    }

}
