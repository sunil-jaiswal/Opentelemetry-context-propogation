/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class Controller {

    @Autowired
    RestTemplate restTemplate;

    @GetMapping(value = "test")
    public String test() {

        final ResponseEntity<String> responseEntity =
            restTemplate.getForEntity("http://10.48.233.156:9090/time", String.class);


        System.out.println(responseEntity.getBody());
        System.out.println(responseEntity.getHeaders().get("Foo"));
        return "Test";
    }
}
