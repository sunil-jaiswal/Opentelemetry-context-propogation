/*
 * package com.example.TimeService.filter; import java.io.IOException; import java.util.Enumeration; import
 * java.util.Iterator; import javax.servlet.Filter; import javax.servlet.FilterChain; import javax.servlet.ServletException;
 * import javax.servlet.ServletRequest; import javax.servlet.ServletResponse; import javax.servlet.http.HttpServletRequest;
 * import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Component; import
 * io.opentelemetry.api.OpenTelemetry; import io.opentelemetry.api.trace.Span; import io.opentelemetry.api.trace.SpanKind;
 * import io.opentelemetry.api.trace.Tracer; import io.opentelemetry.context.Context; import io.opentelemetry.context.Scope;
 * import io.opentelemetry.context.propagation.TextMapGetter;
 * @Component public class ControllerFilter implements Filter {
 * @Autowired Tracer tracer;
 * @Autowired OpenTelemetry openTelemetry; TextMapGetter<HttpServletRequest> getter = new TextMapGetter<HttpServletRequest>()
 * {
 * @Override public Iterable<String> keys(final HttpServletRequest carrier) { final Enumeration<String> e =
 * carrier.getHeaderNames(); return new Iterable<String>() {
 * @Override public Iterator<String> iterator() { return new Iterator<String>() {
 * @Override public boolean hasNext() { return e.hasMoreElements(); }
 * @Override public String next() { return e.nextElement(); }
 * @Override public void remove() { throw new UnsupportedOperationException(); } }; } }; }
 * @Override public String get(final HttpServletRequest carrier, final String key) { return carrier.getHeader(key); } };
 * @Override public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)
 * throws IOException, ServletException { System.out.println("start doFilter"); final HttpServletRequest req =
 * (HttpServletRequest)request; final Context extractedContext =
 * openTelemetry.getPropagators().getTextMapPropagator().extract(Context.current(), req, getter); try (Scope scope =
 * extractedContext.makeCurrent()) { // Automatically use the extracted SpanContext as parent. final Span serverSpan =
 * tracer.spanBuilder("GET /resource").setSpanKind(SpanKind.SERVER).startSpan(); try { // Add the attributes defined in the
 * Semantic Conventions serverSpan.setAttribute("HTTP_METHOD", "GET"); serverSpan.setAttribute("HTTP_SCHEME", "http");
 * serverSpan.setAttribute("HTTP_HOST", "localhost:8080"); serverSpan.addEvent("dofilter"); chain.doFilter(req, response); }
 * finally { try { Thread.sleep(1000); } catch (final InterruptedException e) { // TODO Auto-generated catch block
 * e.printStackTrace(); } serverSpan.end(); } } System.out.println("end doFilter"); } }
 */