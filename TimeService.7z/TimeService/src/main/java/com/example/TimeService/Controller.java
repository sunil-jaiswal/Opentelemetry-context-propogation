/*
 * Copyright (C), the copyright owner 'TomTom', 2022.
 */
package com.example.TimeService;

import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;

@RestController
public class Controller {

    @Autowired
    OpenTelemetry openTelemetry;

    @Autowired
    Tracer tracer;

    TextMapGetter<HttpServletRequest> getter = new TextMapGetter<HttpServletRequest>() {

        @Override
        public Iterable<String> keys(final HttpServletRequest carrier) {
            final Enumeration<String> e = carrier.getHeaderNames();
            return new Iterable<String>() {

                @Override
                public Iterator<String> iterator() {
                    return new Iterator<String>() {

                        @Override
                        public boolean hasNext() {
                            return e.hasMoreElements();
                        }

                        @Override
                        public String next() {
                            return e.nextElement();
                        }

                        @Override
                        public void remove() {
                            throw new UnsupportedOperationException();
                        }
                    };
                }
            };
        }

        @Override
        public String get(final HttpServletRequest carrier, final String key) {
            return carrier.getHeader(key);
        }
    };

    @GetMapping(value = "/time")
    public String time(final HttpServletRequest request) {

        final Context extractedContext =
            openTelemetry.getPropagators().getTextMapPropagator().extract(Context.current(), request, getter);
        try (Scope scope = extractedContext.makeCurrent()) {
            // Automatically use the extracted SpanContext as parent.
            final Span serverSpan = tracer.spanBuilder("Server").setSpanKind(SpanKind.SERVER).startSpan();
            try {
                // Add the attributes defined in the Semantic Conventions
                serverSpan.setAttribute("HTTP_METHOD", "GET");
                serverSpan.setAttribute("HTTP_SCHEME", "http");
                serverSpan.setAttribute("HTTP_HOST", "localhost:8080");
                serverSpan.addEvent("dofilter");

            } finally {
                try {
                    Thread.sleep(1000);
                } catch (final InterruptedException e) {
                    e.printStackTrace();
                }
                serverSpan.end();
            }
        }

        return "It's time to get a watch";

    }

}
